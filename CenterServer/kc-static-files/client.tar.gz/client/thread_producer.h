#ifndef _TRHEADPROD
#define _THREADPROD 1

#include "job.h"
#include <pthread.h>

struct thread_controller
{
	struct thread_controller *next;
	struct thread_controller *prev;
	pthread_t pt;
	void (*routine)(struct routine_arg *);
	struct routine_arg *arg;
	int mode;	// 0 = batch, 1 = non-stop
	int status; // 0 = waiting, 1 = runnning
};
struct thread_controller *thread_head;

struct thread_controller *search_thread_controller(pthread_t);
int new_thread(void (*)(struct routine_arg *), struct routine_arg *);
int reset_thread(pthread_t);
int kill_thread(pthread_t);
void main_routine(struct routine_arg *);
#endif
