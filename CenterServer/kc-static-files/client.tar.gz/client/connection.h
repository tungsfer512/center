#ifndef _CONNECTION
#define _CONNECTION 1

#include <netinet/in.h>
#include <pthread.h>
#define FLOW_SIGNATURE "IOTAGENT2020"

struct flow_header
{
	char signature[12];
	int job_id;
	int payload_size;
	int device_server_id;
};

struct socket_block
{
	struct socket_block *next;
	struct socket_block *prev;
	int sockfd;
	const struct sockaddr_in *addr;
};
struct socket_block *socket_head;
pthread_mutex_t reconnect_mutex;

int create_connection(char *, int);
int search_connection(char *, int);
int reconnect(char *, int);
int send_with_header_parsing(char *, int, int, int, char *, int);
int send_with_header_parsing_known_socket(int, int, int, char *, int);
#endif
