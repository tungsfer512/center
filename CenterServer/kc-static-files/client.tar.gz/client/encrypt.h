#ifndef _ENCRYPT
#define _ENCRYPT 1

#include <openssl/sha.h>

int sha1_buffer(char *, char *, long long);
int sha1_file(char *, char *);
#endif
