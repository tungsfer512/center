#include "thread_producer.h"
#include "connection.h"
#include <signal.h>
#include <unistd.h>
// #include <errno.h>

pthread_mutex_t routine_lock;
pthread_cond_t routine_cond;

int new_thread(void (*routine)(struct routine_arg *), struct routine_arg *arg)
{
	struct thread_controller *tmp = malloc(sizeof(struct thread_controller));
	if (tmp == NULL)
	{
		// printf("[x] new_thread: malloc: %s\n", strerror(errno));
		return -1;
	}

	tmp->next = NULL;
	tmp->routine = routine;
	tmp->arg = arg;
	tmp->mode = arg->mode;
	tmp->status = 1;

	if (thread_head == NULL)
	{
		thread_head = tmp;
		thread_head->prev = NULL;
	}
	else
	{
		struct thread_controller *ptr = thread_head;
		while (ptr->next != NULL)
			ptr = ptr->next;
		ptr->next = tmp;
		tmp->prev = ptr;
	}

	if (pthread_create(&tmp->pt, NULL, routine, arg))
	{
		// printf("[x] new_thread: pthread_create: %s\n", strerror(errno));
		if (tmp->prev != NULL)
			tmp->prev->next = NULL;
		free(tmp);
		return -1;
	}
	return 0;
}

int kill_thread(pthread_t pt)
{
	struct thread_controller *tmp = thread_head;
	while (tmp->pt != pt)
	{
		if (tmp->next == NULL)
		{
			// printf("[x] kill_thread: Thread id not found\n");
			return 0;
		}
		tmp = tmp->next;
	}

	if (tmp->prev != NULL)
		tmp->prev->next = tmp->next;
	if (tmp->next != NULL)
		tmp->next->prev = tmp->prev;

	free(tmp->arg); //arg must malloc()'ed
	free(tmp);

	if (!pthread_kill(pt, SIGTERM))
	{
		// printf("[x] kill_thread: pthread_kill: %s\n", strerror(errno));
		return -1;
	}
	return 0;
}

int reset_thread(pthread_t pt)
{
	struct thread_controller *tmp = thread_head;
	while (tmp->pt != pt)
	{
		if (tmp->next == NULL)
		{
			// printf("[x] kill_thread: Thread id not found\n");
			return 0;
		}
		tmp = tmp->next;
	}

	struct routine_arg *arg = malloc(sizeof(struct routine_arg));
	if (arg == NULL)
	{
		// printf("[x] reset_thread: malloc: %s\n", strerror(errno));
		return -1;
	}

	void (*routine)(struct routine_arg *) = tmp->routine;
	memcpy(arg, tmp->arg, sizeof(struct routine_arg));
	if (kill_thread(pt) < 0)
		return new_thread(routine, arg);
	else
		return -1;
}

struct thread_controller *search_thread_controller(pthread_t pt)
{
	struct thread_controller *tmp = thread_head;
	while (tmp->pt != pt)
	{
		if (tmp->next == NULL)
		{
			// printf("[x] thread controller not found\n");
			return NULL;
		}
		tmp = tmp->next;
	}
	return tmp;
}

void main_routine(struct routine_arg *arg)
{
	create_connection(arg->ip, arg->port);
	if (arg->mode == 0)
	{
		while (1)
		{
			arg->function(arg);
			struct thread_controller *tmp = search_thread_controller(pthread_self());
			pthread_mutex_lock(&routine_lock);

			tmp->status = 0;
			tmp = thread_head;

			int flag = 0;
			while (tmp != NULL)
			{
				if (tmp->mode == 0 && tmp->status == 1)
					flag += 1;
				tmp = tmp->next;
			}
			if (flag > 0)
			{
				pthread_cond_wait(&routine_cond, &routine_lock);
				tmp = search_thread_controller(pthread_self());
				tmp->status = 1;
				pthread_mutex_unlock(&routine_lock);
			}
			else
			{
				struct socket_block *sock_tmp = socket_head;
				while (sock_tmp != NULL)
				{
					int port = ntohs(sock_tmp->addr->sin_port);
					char ip[50];
					memset(ip, 0, 50);
					inet_ntop(AF_INET, &sock_tmp->addr->sin_addr, ip, 50);
					send_with_header_parsing(ip, port, 0xf0, arg->device_id, "end-of-batch\n", 13);
					sock_tmp = sock_tmp->next;
				}
				sleep(5);
				tmp = search_thread_controller(pthread_self());
				tmp->status = 1;
				pthread_cond_broadcast(&routine_cond);
				pthread_mutex_unlock(&routine_lock);
			}
		}
	}
	else
	{
		while (1)
			arg->function(arg);
	}
}
