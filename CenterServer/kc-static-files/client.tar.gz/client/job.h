#ifndef _JOB
#define _JOB 1

struct routine_arg
{
	char *ip;
	int port;
	int job_id;
	int device_id;    // device id stored in server db
	void (*function)(struct routine_arg *);
	char *char_arg1;  // filename
	char **char_arg2; // matching pattern
	char *char_arg3;  // last line
	int int_arg1;	  //
	int int_arg2;	  // 1 = continuous
	int mode;		  // 0 = batch, 1 = non-stop
};					  // must use malloc()
struct routine_arg *create_routine_arg(char *, int, int, int,  void (*)(struct routine_arg *), char *, char *, char *, int, int, int);

struct hash_table_entry {
    struct hash_table_entry * next_entry;
    char * filename;
    char * hash;
};

struct hash_table {
    struct hash_table_entry * start;
    struct hash_table_entry * end;
};


void get_file_content(struct routine_arg *);
// void packet_capturing(struct routine_arg *);
int packet_capturing(int accept_sock, int device_server_ip, char* ip, int port);
void get_mac_list(struct routine_arg *);
void get_process_info(struct routine_arg *);
void get_proc_info(struct routine_arg *);
void check_integrity(struct routine_arg *);
//struct hash_table_entry * create_new_hash_entry( char *);
//void hash_files_recursively(char *, struct hash_table *);
#endif
