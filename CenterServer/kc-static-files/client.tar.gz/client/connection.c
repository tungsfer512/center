#include "connection.h"
#include <arpa/inet.h>
// #include <errno.h>

pthread_mutex_t create_mtx;
pthread_mutex_t send_mtx;

int search_connection(char *ip, int port)
{
	if (socket_head == NULL)
		return 0;
	if (port <= 0 || port >= 65536)
	{
		// printf("[x] search_connection: Invalid port\n");
		return -1;
	}
	if (inet_addr(ip) < 0)
	{
		// printf("[x] search_connection: Invalid IP address\n");
		return -1;
	}

	struct socket_block *tmp = socket_head;
	while (port != ntohs(tmp->addr->sin_port) || strcmp(ip, inet_ntoa(tmp->addr->sin_addr)))
	{
		if (tmp->next == NULL)
		{
			// printf("[x] search_connection: connection not found\n");
			return -1;
		}
		tmp = tmp->next;
	}
	return tmp->sockfd;
}

int create_connection(char *ip, int port)
{
	int sockfd = 0;
	struct sockaddr_in *addr = NULL;
	struct socket_block *sbl = NULL;

	if (port <= 0 || port >= 65536)
	{
		// printf("[x] create_connection: Invalid port\n");
		return -1;
	}
	if (inet_addr(ip) < 0)
	{
		// printf("[x] create_connection: Invalid IP address\n");
		return -1;
	}
	pthread_mutex_lock(&create_mtx);
	sockfd = search_connection(ip, port);
	if (sockfd > 0)
	{
		pthread_mutex_unlock(&create_mtx);
		return sockfd;
	}
	if ((sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) <= 0)
	{
		// printf("[x] create_connection: socket: %s\n", strerror(errno));
		goto FAIL_CREATE_CONNECTION;
	}
	addr = malloc(sizeof(struct sockaddr_in));
	if (addr == NULL)
	{
		// printf("[x] create_connection: malloc: %s\n", strerror(errno));
		goto FAIL_CREATE_CONNECTION;
	}
	addr->sin_family = AF_INET;
	addr->sin_port = htons(port);
	if (inet_pton(AF_INET, ip, &addr->sin_addr) != 1)
	{
		// printf("[x] create_connection: inet_pton: %s\n", strerror(errno));
		goto FAIL_CREATE_CONNECTION;
	}
	if (connect(sockfd, addr, sizeof(struct sockaddr_in)) < 0)
	{
		// printf("[x] create_connection: connect: %s\n", strerror(errno));
		goto FAIL_CREATE_CONNECTION;
	}

	sbl = malloc(sizeof(struct socket_block));
	if (sbl == NULL)
	{
		// printf("[x] create_connnection: malloc: %s\n", strerror(errno));
		goto FAIL_CREATE_CONNECTION;
	}
	sbl->next = NULL;
	sbl->sockfd = sockfd;
	sbl->addr = addr;
	if (socket_head == NULL)
		socket_head = sbl;
	else
	{
		struct socket_block *tmp = socket_head;
		while (tmp->next != NULL)
			tmp = tmp->next;
		tmp->next = sbl;
		sbl->prev = tmp;
	}
	pthread_mutex_unlock(&create_mtx);
	return sockfd;

FAIL_CREATE_CONNECTION:
	if (sockfd > 0)
	{
		shutdown(sockfd, 1);
		close(sockfd);
	}
	if (addr != NULL)
		free(addr);
	if (sbl != NULL)
		free(sbl);
	pthread_mutex_unlock(&create_mtx);
	return -1;
}

int reconnect(char *ip, int port)
{
	struct socket_block *tmp = socket_head;

	while (port != ntohs(tmp->addr->sin_port) || strcmp(ip, inet_ntoa(tmp->addr->sin_addr)) != 0)
	{
		if (tmp->next = NULL)
		{
			// printf("[x] reconnect: sockfd not found\n");
			return -1;
		}
		tmp = tmp->next;
	}

	if (send(tmp->sockfd, "IOTAGENT2020\x00\x00\x00\xff\x00\x00\x00\x00\x00\x00\x00\x00", 24, 0) >= 0)
	{
		return tmp->sockfd;
	}
	do
	{
		if (tmp->sockfd > 0)
		{
			shutdown(tmp->sockfd, 1);
			close(tmp->sockfd);
		}
		tmp->sockfd = socket(AF_INET, SOCK_STREAM, 0);
	} while (connect(tmp->sockfd, tmp->addr, sizeof(struct sockaddr_in)) < 0);

	return tmp->sockfd;
}

int send_with_header_parsing(char *ip, int port, int job_id, int device_server_id, char *data, int datalen)
{
	pthread_mutex_lock(&send_mtx);
	int sockfd;

	while ((sockfd = create_connection(ip, port)) < 0)
		;

	char buffer[datalen + sizeof(struct flow_header)];
	memset(buffer, 0, datalen + sizeof(struct flow_header));

	((struct flow_header *)buffer)->payload_size = htonl(datalen);
	((struct flow_header *)buffer)->job_id = htonl(job_id);
	((struct flow_header *)buffer)->device_server_id = htonl(device_server_id);
	memcpy(buffer, FLOW_SIGNATURE, 12);
	memcpy(buffer + sizeof(struct flow_header), data, datalen);

	int res;
	while ((res = send(sockfd, buffer, datalen + sizeof(struct flow_header), 0)) < 0)
	{
		sockfd = reconnect(ip, port);
	}
	pthread_mutex_unlock(&send_mtx);
	return res;
}


int send_with_header_parsing_known_socket (int sockfd, int job_id, int device_server_id, char * data, int datalen) {

	//printf("[!] 0x%x sending\n", job_id);
	char buffer[datalen + sizeof(struct flow_header)];
	memset(buffer, 0, datalen + sizeof(struct flow_header));
	((struct flow_header *)buffer)->payload_size = htonl(datalen);
	((struct flow_header *)buffer)->job_id = htonl(job_id);
	((struct flow_header *)buffer)->device_server_id = htonl(device_server_id);

	memcpy(buffer, FLOW_SIGNATURE, 12);
	memcpy(buffer + sizeof(struct flow_header), data, datalen);
	int res = send(sockfd, buffer, datalen + sizeof(struct flow_header), 0);

	return res;
	
}
