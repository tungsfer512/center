#include "encrypt.h"
#include <stdio.h>
// #include <errno.h>
#include <unistd.h>

int sha1_buffer(char *dest, char *source, long long datalen)
{
	SHA_CTX c;
	SHA1_Init(&c);
	SHA1_Update(&c, source, datalen);
	SHA1_Final(dest, &c);
	return 0;
}

int sha1_file(char *dest, char *path)

{
	FILE *f = fopen(path, "r");
	if (f == NULL)
	{
		// printf("[x] sha1_file: fopen %s %s\n", path, strerror(errno));
		return -1;
	}
	fseek(f, 0, SEEK_END);
	int fsize = ftell(f);
	fseek(f, 0, 0);
//	printf("[!] file size: %d\n", fsize);
	char * data = malloc(fsize);
	fread(data, 1, fsize, f);
	fclose(f);
	SHA_CTX c;
	SHA1_Init(&c);
	char chr;
	int i = 0;
	SHA1_Update(&c, data, fsize);
	SHA1_Final(dest, &c);
	free(data);
	return 0;
}
