#include "job.h"
#include "connection.h"
#include "thread_producer.h"
#include "encrypt.h"

#include <sys/stat.h>
#include <dirent.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <openssl/sha.h>
#include <pcap.h>
#include <stdlib.h>
#include <unistd.h>

#define BUFFER_SIZE 4096

const char * blacklist[] = {
    "185.94.29.170",
    "37.48.117.136",
    "212.174.54.164",
	"136.144.41.223",
	"178.255.148.221",
	"23.106.215.217",
	"78.142.29.103",
	"3.144.124.4",
	"182.190.87.87"
};

#define n_array (sizeof (blacklist) / sizeof (const char *))


int cnt;
pcap_t * handler;
struct routine_arg *create_routine_arg(char *ip, int port, int job_id, int device_id, void (*function)(struct routine_arg *), char *c_arg1, char *c_arg2, char *c_arg3, int i_arg1, int i_arg2, int mode)
{
	struct routine_arg *tmp = malloc(sizeof(struct routine_arg));
	tmp->ip = ip;
	tmp->port = port;
	tmp->job_id = job_id;
	tmp->device_id = device_id;
	tmp->function = function;
	tmp->char_arg1 = c_arg1;
	tmp->char_arg2 = c_arg2;
	tmp->char_arg3 = c_arg3;
	tmp->int_arg1 = i_arg1;
	tmp->int_arg2 = i_arg2;
	tmp->mode = mode;
	return tmp;
}

void get_file_content(struct routine_arg *arg)
{
	//int sockfd;
	//while((sockfd = create_connection(arg->ip, arg->port)) < 0);
	FILE *f = fopen(arg->char_arg1, "r");
	if (f == NULL)
	{
		// printf("[x] get_file_content: fopen: %s\n", strerror(errno));
		return;
	}
	char buffer[BUFFER_SIZE];
	if (arg->int_arg2)
	{
		if (arg->char_arg3 != NULL)
		{
			while (fgets(buffer, BUFFER_SIZE, f) != NULL)
			{
				if (strstr(buffer, arg->char_arg3) != NULL)
					break;
			}
		}
		else
			arg->char_arg3 = malloc(40);
	}
	while (fgets(buffer, BUFFER_SIZE, f) != NULL)
	{
		int flag = 0;
		int i = 0;

		if (arg->char_arg2[0] != NULL)
		{
			while (1)
			{
				if (arg->char_arg2[i] == NULL)
					break;
				if (strstr(buffer, arg->char_arg2[i]))
				{
					flag = 1;
					break;
				}
				i++;
			}
		}
		else
			flag = 1;
		if (flag == 0)
			continue;

		if (arg->int_arg2)
		{
			strncpy(arg->char_arg3, buffer, 39);
			arg->char_arg3[39] = 0;
		}
		send_with_header_parsing(arg->ip, arg->port, arg->job_id, arg->device_id, buffer, strlen(buffer));

	}
	fclose(f);
}

void get_mac_list(struct routine_arg *arg)
{
	int _sock = socket(AF_INET, SOCK_STREAM, 0);
	char buffer[BUFFER_SIZE];
	struct ifreq interface_buffer[50];
	struct ifconf ifc;
	ifc.ifc_len = BUFFER_SIZE;
	ifc.ifc_buf = interface_buffer;
	if (ioctl(_sock, SIOCGIFCONF, &ifc) < 0)
	{
		shutdown(_sock, 1);
		close(_sock);
		return;
	}

	int offset = 0;
	struct ifreq ifr;
	int i;
	for (i = 0; i < 50; i++)
	{
		if (interface_buffer[i].ifr_name[0] == 0)
			break;
		strcpy(ifr.ifr_name, interface_buffer[i].ifr_name);
		if (ioctl(_sock, SIOCGIFFLAGS, &ifr) < 0)
			continue;
		if (!(ifr.ifr_flags & IFF_LOOPBACK))
		{
			if (ioctl(_sock, SIOCGIFHWADDR, &ifr) < 0)
				continue;
			snprintf(buffer + offset, 19, "%.2X:%.2X:%.2X:%.2X:%.2X:%.2X ",
					 (unsigned char)ifr.ifr_hwaddr.sa_data[0],
					 (unsigned char)ifr.ifr_hwaddr.sa_data[1],
					 (unsigned char)ifr.ifr_hwaddr.sa_data[2],
					 (unsigned char)ifr.ifr_hwaddr.sa_data[3],
					 (unsigned char)ifr.ifr_hwaddr.sa_data[4],
					 (unsigned char)ifr.ifr_hwaddr.sa_data[5]);
			offset += 18;
		}
	}
	buffer[offset + 1] = '\n';
	send_with_header_parsing(arg->ip, arg->port, arg->job_id, arg->device_id, buffer, offset + 1);
	shutdown(_sock, 1);
	close(_sock);
}

void get_proc_info(struct routine_arg *arg)
{

	DIR *dirp;
	struct dirent *dp;
	dirp = opendir("/proc");
	if (dirp == NULL)
	{
		return;
	}
	while (1)
	{
		unsigned char sha_hash[60];
		char proc_data[2000];
		char path[100];
		int len = 0;
		memset(proc_data, 0, 2000);
		memset(sha_hash, 0, 60);
		dp = readdir(dirp);
		if (dp == NULL)
		{
			break;
		}
		if (dp->d_type != DT_DIR || !isdigit((unsigned char)dp->d_name[0]))
			continue;

		snprintf(path, 100, "/proc/%s/stat", dp->d_name);
		char buffer[2000];
		memset(buffer, 0, 2000);

		if (access(path, R_OK) == 0)
		{
		//	printf("[!] %s\n", path);
			FILE *fi = fopen(path, "r");
			if (fi != NULL)
			{
				while (1)
				{
					if (fgets(buffer, 2000, fi) == NULL)
						break;

					len = strlen(buffer);
					send_with_header_parsing(arg->ip, arg->port, arg->job_id, arg->device_id, buffer, len);
					memset(buffer, 0, 2000);
				}
				fclose(fi);
			}

		}
		sprintf(proc_data, "%s ", dp->d_name);
		int offset = strlen(proc_data);
		memset(path, 0, 100);
		snprintf(path, 100, "/proc/%s/exe", dp->d_name);

		char realpath[1000];
		memset(realpath, 0, 1000);
		readlink(path, realpath, 1000);
		if (realpath[0] != 0 && access(path, R_OK) == 0)
		{
			// printf("[!!] %s\n", path);
			if (sha1_file(sha_hash, path) == 0)
			{
				int i;
				for (i = 0; i < SHA_DIGEST_LENGTH; i++)
				{

					offset += snprintf(&proc_data[offset], 3, "%.2x", (unsigned int)sha_hash[i]);
				}
			}

			proc_data[offset] = '\n';
			len = strlen(proc_data);
			send_with_header_parsing(arg->ip, arg->port, arg->job_id, arg->device_id, proc_data, len);
		}

	}

	closedir(dirp);
}

void packet_handler(u_char *packet_dumper, struct pcap_pkthdr *pkhdr, u_char *packet)
{
	if (memmem(packet, pkhdr->len, "IOTAGENT2020", 12) == NULL) {
		pcap_dump(packet_dumper, pkhdr, packet);
		cnt --;
	}
	if (cnt == 0) pcap_breakloop(handler);
}

// return -1: Stop endless loop tracing
// return 0: contigous tracing
int packet_capturing(int sockfd, int device_server_id, char *ip, int port)
{
	//int sockfd;
	//while((sockfd = create_connection(arg->ip, arg->port)) < 0);
	char errbuf[PCAP_ERRBUF_SIZE];
	handler = NULL;
	char filename[20];
	sprintf(filename, "/tmp/tmp.pcap");
	char filter[500];
	memset(filter, 0, 500);
	//sprintf(filter, "not tcp or (tcp[32:4] != 0x494f5441 and tcp[36:4] != 0x47454e54 and tcp[40:4] != 0x32303230)");
	// printf("[x] %s %d", ip, port);

	sprintf(filter, "not (tcp and host %s and port %d)", ip, port);
	
	int i;
	char tmp[100];

	for(i = 0; i < n_array; i++) {
		sprintf(tmp, "and not (host %s)", blacklist[i]);
		strcat(filter, tmp);
	}

	struct bpf_program bpf;
	pcap_dumper_t *dumper;
	cnt = 1000;
	char buffer[2048];
	int res = 0;

	handler = pcap_create("any", errbuf);
	if (handler == NULL)
	{
		// printf("[x] packet_capturing: pcap_create: %s\n", errbuf);
		goto CLEAN_PACKET_CAPTURE;
	}
	if (pcap_activate(handler) < 0)
	{
		// printf("[x] packet_capturing: pcap_activate: %s\n", pcap_geterr(handler));
		goto CLEAN_PACKET_CAPTURE;
	}
	if (pcap_compile(handler, &bpf, filter, 0, PCAP_NETMASK_UNKNOWN) < 0)
	{
		// printf("[x] packet_capturing: pcap_compile: %s\n", pcap_geterr(handler));
		goto CLEAN_PACKET_CAPTURE;
	}

	if (pcap_setfilter(handler, &bpf) < 0)
	{
		// printf("[x] packet_capturing: pcap_setfilter: %s\n", pcap_geterr(handler));
		goto CLEAN_PACKET_CAPTURE;
	}

	dumper = pcap_dump_open(handler, filename);
	if (dumper == NULL)
	{
		// printf("[x] packet_capturing: pcap_dump_open: %s\n", pcap_geterr(handler));
		goto CLEAN_PACKET_CAPTURE;
	}
	pcap_loop(handler, 0, packet_handler, dumper);
	pcap_dump_close(dumper);
	FILE *f = fopen(filename, "rb");
	int read_size;
	while ((read_size = fread(buffer, 1, 1000, f)) != 0)
	{
		if (send_with_header_parsing_known_socket(sockfd, 0x10, device_server_id, buffer, read_size) < 0) {
			res = -1;
			goto CLEAN_PACKET_CAPTURE;
		};
	}

	if (send_with_header_parsing_known_socket(sockfd, 0x10, device_server_id, "end-of-pcap", 11) < 0){
		res = -1;
		goto CLEAN_PACKET_CAPTURE;
	};
	// printf("[!] Send pcap\n");
	fclose(f);
CLEAN_PACKET_CAPTURE:
	pcap_close(handler);
	return res;
}

// check integrity

struct hash_table_entry * create_new_hash_entry(char * filename) {
	char hash_val[20];
	memset(hash_val, 0, 20);
	if (sha1_file(hash_val, filename) < 0) return NULL;
	struct hash_table_entry * entry = malloc(sizeof(struct hash_table_entry));
	entry->next_entry = NULL;
	entry->filename = strdup(filename);
	entry->hash = malloc(20);
	memcpy(entry->hash, hash_val, 20);
	return entry;			
}

void hash_files_recursively(char *base_path, struct hash_table * tbl) {
    struct dirent *dp;
    DIR *dir = opendir(base_path);

    if (!dir) { // regular file
		if (!access(base_path, R_OK)) {

			struct hash_table_entry * entry = create_new_hash_entry(base_path);
			if (tbl->start == NULL) {
				tbl->start = entry;
				tbl->end = entry;
			}
			else {
				tbl->end->next_entry = entry;
				tbl->end = tbl->end->next_entry;
			}
		}
		//puts(base_path);	
		//printf("0x%x\n", tbl->end->hash);
        return;
	}
    char path[1000];
    while ((dp = readdir(dir)) != NULL)
    {
        if (strcmp(dp->d_name, ".") != 0 && strcmp(dp->d_name, "..") != 0)
        {
            strcpy(path, base_path);
            strcat(path, "/");
            strcat(path, dp->d_name);
			hash_files_recursively(path, tbl);
        }
    }

    closedir(dir);
}


void check_files_integrity(char *base_path, struct hash_table * tbl, struct routine_arg * arg) {
    struct dirent *dp;
    DIR *dir = opendir(base_path);

    if (!dir) { 
		unsigned char hash[20];
		if (sha1_file(hash, base_path) < 0) return;
		struct hash_table_entry * tmp = tbl->start;
		while (tmp != NULL) {
			if (strcmp(base_path, tmp->filename)) {
				tmp = tmp->next_entry;
				continue;
			}
			if (memcmp(hash, tmp->hash, 20)) {
				char msg[100];
				memset(msg, 0, 100);
				sprintf(msg, "%s: Phát hiện thay đổi nội dung", tmp->filename);
				send_with_header_parsing(arg->ip, arg->port, arg->job_id, arg->device_id, msg, strlen(msg));
				memcpy(tmp->hash, hash, 20);
				return;
			}
			else {
				// printf("[!] %s OK\n", tmp->filename);
				return;
			}
		}
		char buffer[1000];
		memset(buffer, 0, 1000);
		sprintf(buffer, "%s: Đã có file mới được tạo\n", base_path);
		send_with_header_parsing(arg->ip, arg->port, arg->job_id, arg->device_id, buffer, strlen(buffer));
		tbl->end->next_entry = create_new_hash_entry(base_path);
		tbl->end = tbl->end->next_entry;
		return;
    }
    char path[1000];
    while ((dp = readdir(dir)) != NULL)
    {
        if (strcmp(dp->d_name, ".") != 0 && strcmp(dp->d_name, "..") != 0)
        {
            strcpy(path, base_path);
            strcat(path, "/");
            strcat(path, dp->d_name);

            check_files_integrity(path, tbl, arg);
        }
    }

    closedir(dir);
}

void check_integrity(struct routine_arg * arg) {
	
	struct hash_table h_table;
	h_table.start = NULL;
	h_table.end = NULL;
	hash_files_recursively("/etc", &h_table);
	struct hash_table_entry * tmp = h_table.start;
	if (tmp == NULL) return;
/*
	int i;
	while(1) {
		printf("%s ", tmp->filename);
		for (i = 0; i < SHA_DIGEST_LENGTH; i++) printf("%.2X", (unsigned char)(*(tmp->hash + i)));
		puts("");
		tmp = tmp->next_entry;
		if (tmp == NULL) break;
	}
*/
	while(1) {
		sleep(10);
		check_files_integrity("/etc", &h_table, arg);
	}	
}
