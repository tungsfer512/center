#include "thread_producer.h"
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include "remote.h"

void main(int argc, char **argv[])
{
	signal(SIGPIPE, SIG_IGN);
	printf("PID: %d\n", getpid());

	char *pattern[] = {"cpu", "proc", NULL};
	char *default_pattern[] = {NULL};
	char *meminfo_pattern[] = {"Mem", "Buffer", "Cache", "Swap", NULL};
	char *server_ip = "127.0.0.1";
	int device_server_id = -1;
	int remote_port = 3333;
	char *p;
	if (argc > 2)
		server_ip = argv[1];
		device_server_id = strtol(argv[2], &p, 10);
		remote_port = strtol(argv[3], &p, 10);
		printf("DEBUG: %d %d\n", device_server_id, remote_port);
	
	new_thread(main_routine, create_routine_arg(server_ip, 2020, 1, device_server_id, get_file_content, "/proc/uptime", default_pattern, NULL, 0, 0, 0));
	new_thread(main_routine, create_routine_arg(server_ip, 2020, 1, device_server_id, get_file_content, "/proc/stat", pattern, NULL, 0, 0, 0));
	new_thread(main_routine, create_routine_arg(server_ip, 2020, 2, device_server_id, get_file_content, "/proc/meminfo", meminfo_pattern, NULL, 0, 0, 0));

	new_thread(main_routine, create_routine_arg(server_ip, 2020, 3, device_server_id, get_proc_info, NULL, default_pattern, NULL, 0, 0, 0));

	new_thread(main_routine, create_routine_arg(server_ip, 2020, 4, device_server_id, get_file_content, "/proc/net/tcp", default_pattern, NULL, 0, 0, 0));
	new_thread(main_routine, create_routine_arg(server_ip, 2020, 5, device_server_id, get_file_content, "/proc/net/tcp6", default_pattern, NULL, 0, 0, 0));
	new_thread(main_routine, create_routine_arg(server_ip, 2020, 6, device_server_id, get_file_content, "/proc/net/udp", default_pattern, NULL, 0, 0, 0));
	new_thread(main_routine, create_routine_arg(server_ip, 2020, 7, device_server_id, get_file_content, "/proc/net/udp6", default_pattern, NULL, 0, 0, 0));
	new_thread(main_routine, create_routine_arg(server_ip, 2020, 8, device_server_id, get_file_content, "/proc/net/dev", default_pattern, NULL, 0, 0, 0));

	if (access("/var/log/syslog", F_OK) != -1)
		new_thread(main_routine, create_routine_arg(server_ip, 2020, 9, device_server_id, get_file_content, "/var/log/syslog", default_pattern, NULL, 0, 1, 0));
	else if (access("/var/log/message", F_OK) != -1)
		new_thread(main_routine, create_routine_arg(server_ip, 2020, 9, device_server_id, get_file_content, "/var/log/message", default_pattern, NULL, 0, 1, 0));
	else if (access("/tmp/syslog.log", F_OK) != -1)
		new_thread(main_routine, create_routine_arg(server_ip, 2020, 9, device_server_id, get_file_content, "/tmp/syslog.log", default_pattern, NULL, 0, 1, 0));

	new_thread(main_routine, create_routine_arg(server_ip, 2020, 10, device_server_id, get_mac_list, NULL, default_pattern, NULL, 0, 0, 0));

	// new_thread(main_routine, create_routine_arg(server_ip, 2020, 0x10, device_server_id, packet_capturing, NULL, default_pattern, NULL, 0, 0, 1));

	new_thread(main_routine, create_routine_arg(server_ip, 2020, 11, device_server_id, check_integrity, NULL, default_pattern, NULL, 0, 0, 1));	

	remote_handler(device_server_id, server_ip, 2020, remote_port);


	while (1)
		; //prevent thread terminated on main exit
}
